package be.mobyus.hibernate.entities.inheritance;

public class BillingAddress extends Address {

}
