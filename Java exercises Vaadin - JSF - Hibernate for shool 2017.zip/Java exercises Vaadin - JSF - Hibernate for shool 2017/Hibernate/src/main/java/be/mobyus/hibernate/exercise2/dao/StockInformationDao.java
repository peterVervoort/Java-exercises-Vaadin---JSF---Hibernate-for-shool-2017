package be.mobyus.hibernate.exercise2.dao;

/**
 * Created by java on 08.03.17.
 */
public interface StockInformationDao {
}
