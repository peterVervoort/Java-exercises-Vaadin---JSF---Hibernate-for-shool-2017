package be.mobyus.util;

import net.sf.ehcache.management.CacheManagerMBean;

public interface CacheManagementServiceMBean extends CacheManagerMBean {

}
