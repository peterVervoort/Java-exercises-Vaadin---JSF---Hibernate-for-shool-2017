package be.mobyus.hibernate.exercise2.entities;

/**
 * Created by java on 08.03.17.
 */
public class Book {
}

/*
    Book bookId Long
        Book bookName String
        BookDetails ISBN String
        BookDetails Publisher String
*/