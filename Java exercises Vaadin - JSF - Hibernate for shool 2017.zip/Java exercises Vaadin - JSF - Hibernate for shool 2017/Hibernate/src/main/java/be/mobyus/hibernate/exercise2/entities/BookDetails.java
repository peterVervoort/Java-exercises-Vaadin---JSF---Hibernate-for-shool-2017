package be.mobyus.hibernate.exercise2.entities;

/**
 * Created by java on 08.03.17.
 */
public class BookDetails {
}
